# Các báo cáo phiên đã làm

| Ngày phiên | Dự án | Báo cáo / slide | Ghi chú |
|---|---|---|---|
| 31/10 | Cừu cầm ô `work/test/spine/SheepUmbrella/` | https://claude.ai/artifact/W9D1JAsfQwgSpDbd86ThtZ (video `review/`) | ~2 g 05, AI gen 65,8′, 0 key tay; active 6 lượt |
| 02/11 | Cừu Sakura `work/test/spine/CuuSakura/` | https://claude.ai/artifact/HgG4x79B3x41dbM1TnxWT6 | ~2 g 26, AI gen 59′, ~95 thao tác tay; người key nhịp chính |
| 02–03/11 | Cừu đi học `work/test/spine/MascotBackToSchool/` | https://claude.ai/artifact/EDbL3uDfdQq5RZtonN8JAB (`_review/BAO_CAO.md`) | ~1 g 39, AI gen 50′; nhanh nhất nhờ skill |
| 30/10 | Hộp quà `work/test/spine/GiftBox/` | trong slide gộp (slide 19–22) | asset không tách: 6 vòng sửa mesh, dừng trước anim |
| 03/11 | Slide gộp 3 cừu + Hộp quà | https://claude.ai/artifact/82UDQXqceiZ41Pxc2ZrBrb | 23 slide, 38 video; mẫu slide ở `templates/slides/` |
| 02–03/11 | G-LumberCity 3D (rig Worker + Idle Wipe, Clean Output, Ropeway Crank) `work/g_lumbercity/_review/` | https://claude.ai/artifact/VRwnySDgzodPvswDX4ZKV2 · slide https://claude.ai/artifact/VYE5ChpnU2nMnFAwiCHgUG (nguồn `_review/slides/`) | đầu tiên cho 3D + nhiều phiên fork song song: AI gen 3 g 59′ (4 phiên có log), 3 g 18′ gen trong 2 g 24′ song song; phiên Idle Wipe mất log → dựng lại từ git; 0 key tay, yếu ở ý đồ diễn + director sót 2 lỗi |
| 28/10–04/11 | Ninja 3D (Idle + Attack Studio, Skill 1 Frolvy) `work/infinite_defense/_review/` | `BAO_CAO.md`, `BAO_CAO.html`, `SLIDE.html` (file cục bộ, chưa đăng artifact) | 210 lượt, AI gen 15 g 50′, người 8 g 06′; điểm yếu lặp: đổi pose đã duyệt; chưa có video Attack / Skill 1 |
| 05–11/11 | Windy 3D (Idle + Attack + Skill 1, Frolvy) `work/endless_kicker/_review/` | `BAO_CAO.md`, `BAO_CAO.html`, `SLIDE.html` (file cục bộ, chưa đăng artifact: phiên không có công cụ Artifact) | 186 lượt, AI gen 8 g 37′, người 9 g 01′ (5 phiên); 6 video playblast camera game (`v/`); điểm yếu lớn: overlap vải ~3 g 29′ cả Attack + Skill 1, tự ý đổi phần người không bảo |
| 04–13/11 | Hero RPG2 3D Frolvy (rig + Idle, Attack 1, Attack 2, Deadly Strike, vải / giáp) `work/rpg2_hero/_review/` | https://claude.ai/artifact/XmaRqTmKiEUVeBcD6kCEJD · slide https://claude.ai/artifact/MJdjdBbqr91iJ6ReoHM8La (nguồn `_review/slides/`) | 7 phiên, 327 lượt, AI gen 8 g 40′, người 15 g 40′; 73 lượt chê, 62 lần "chưa xem bằng mắt"; người key pose chính đòn đánh; gộp giai đoạn bằng `_review/aggregate.py` (cắt fork theo giờ, sửa lượt dính sự kiện nhánh) |
